//VALORES DO HTML ESTÁTICO
//CGM - EMAIL - IDADE
const nome=document.getElementById("nome");
const sobrenome = document.getElementById("sobrenome");
const cgm = document.getElementById("CGM");
const idade = document.getElementById("IDADE");
const eMail = document.getElementById("EMAIL");

//VALORES DE VARIAVEIS 
const novoNome = "Brenno"
const Sobrenome2 = "Chimanski"
const novoCgm = 12345678
const novaIdade = 16
const novoeMail = "tetakonacama@hotemail.COM2008"

//NOVOS VALORES ATRIBUIDOS DE FORMA DINÂMICA
nome.innerHTML=novoNome
sobrenome.innerHTML = sobrenome2
cgm.innerHTML = novoCgm
idade.innerHTML = novaIdade
email.innerHTML = novoeMail