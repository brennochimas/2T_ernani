// metodos de arrey
const comidas = ['churrasco', 'pizza'];
comidas[3] = 'sushi';
comidas.push('berinjela');// emourrando um valor para o finallista
comidas.pop()// retira um valor do final da lista 
comidas.shift() //retrirada de um elemento do inicio 
comidas.unshift('mamão') // inserir um item no inicio da lista 

console.log(comidas.length)
const tamanho = comidas.length;
console.log('existem' + 'itens na lista ')

console.log(comidas)
