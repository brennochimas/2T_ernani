/**  
 * declaração de variaveis javascript
 * indentificador: nome da variavel
 * valor da variavel
 */
const sobrenome = "Chimanski"
const nome = "Brenno"
const idade = 16;
//REATRIBUINDO VALORES
//pet = "Zara";
//nome = "Brenno";
// PI : 16
const dadospessoais = nome + " " + sobrenome + " " + idade
const ano = 2024
const anoNascimento = 2008
const idadeAtual = ano - anoNascimento
console.log(idadeAtual + " anos");
const num = 24
const parOuimpar = num % 2 === 0 //par
const imparOupar = num % 2 === 1 //impar

console.log(parOuimpar)
console.log(imparOupar)

//crie uma variavel para cada situação
const passatempo = "Treinar"
const cidade = "Curitiba"
const preoçoDolar = 5.12
const animalDeEstimação = "pitbull"
const estaSolteiro = "false"
const todososdados = passatempo + " " + cidade + " " + preoçoDolar + " " + animalDeEstimação + "   " + estaSolteiro
console.log(passatempo + " " + cidade + " " + preoçoDolar + " " + animalDeEstimação + "   " + estaSolteiro)
